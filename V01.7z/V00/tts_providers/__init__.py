# TTS Providers Package
from .azure_tts import AzureTTSProvider
from .google_tts import GoogleTTSProvider

__all__ = ['AzureTTSProvider', 'GoogleTTSProvider']