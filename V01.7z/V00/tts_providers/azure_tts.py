import os
from typing import Optional
import azure.cognitiveservices.speech as speechsdk
from ..tts_factory import TTSProvider
from ..logger import tts_logger

class AzureTTSProvider(TTSProvider):
    def __init__(self, subscription_key: Optional[str] = None, region: Optional[str] = None):
        self.subscription_key = subscription_key or os.getenv('AZURE_TTS_KEY')
        self.region = region or os.getenv('AZURE_TTS_REGION', 'eastus')
        if not self.subscription_key:
            raise ValueError('Azure TTS subscription key is required')
        
        self.speech_config = speechsdk.SpeechConfig(
            subscription=self.subscription_key,
            region=self.region
        )
        tts_logger.info('Azure TTS provider initialized')
    
    async def generate_speech(
        self,
        text: str,
        voice_name: str = 'zh-CN-XiaoxiaoNeural',
        speed: float = 1.0,
        output_file: str = None
    ) -> bool:
        try:
            tts_logger.info('Starting Azure TTS generation with voice: %s', voice_name)
            tts_logger.debug('Sending TTS request with text length: %d', len(text))
            
            # 设置语音和语速
            self.speech_config.speech_synthesis_voice_name = voice_name
            self.speech_config.speech_synthesis_rate = int((speed - 1) * 100)
            
            # 设置音频输出
            audio_config = speechsdk.AudioConfig(filename=output_file)
            
            # 创建语音合成器
            synthesizer = speechsdk.SpeechSynthesizer(
                speech_config=self.speech_config,
                audio_config=audio_config
            )
            
            # 执行语音合成
            result = synthesizer.speak_text_async(text).get()
            
            if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
                tts_logger.info('Audio file saved successfully to: %s', output_file)
                return True
            else:
                tts_logger.error(
                    'Speech synthesis failed: %s',
                    result.cancellation_details.reason
                )
                return False
                
        except Exception as e:
            tts_logger.error('Azure TTS generation failed: %s', str(e))
            return False