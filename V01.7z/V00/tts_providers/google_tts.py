import os
from typing import Optional
from google.cloud import texttospeech
from ..tts_factory import TTSProvider
from ..logger import tts_logger

class GoogleTTSProvider(TTSProvider):
    def __init__(self, credentials_path: Optional[str] = None):
        self.credentials_path = credentials_path or os.getenv('GOOGLE_APPLICATION_CREDENTIALS')
        if self.credentials_path:
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = self.credentials_path
        
        # 初始化客户端
        self.client = texttospeech.TextToSpeechClient()
        tts_logger.info('Google TTS provider initialized')
    
    async def generate_speech(
        self,
        text: str,
        voice_name: str = 'zh-CN-Standard-A',
        speed: float = 1.0,
        output_file: str = None
    ) -> bool:
        try:
            tts_logger.info('Starting Google TTS generation with voice: %s', voice_name)
            tts_logger.debug('Sending TTS request with text length: %d', len(text))
            
            # 设置输入文本
            synthesis_input = texttospeech.SynthesisInput(text=text)
            
            # 解析语音名称（格式：语言代码-声音名称）
            language_code = voice_name.split('-')[0] + '-' + voice_name.split('-')[1]
            voice_name_parts = voice_name.split('-')
            if len(voice_name_parts) >= 3:
                voice_type = '-'.join(voice_name_parts[2:])
            else:
                voice_type = 'Standard-A'
            
            # 设置语音参数
            voice = texttospeech.VoiceSelectionParams(
                language_code=language_code,
                name=voice_name
            )
            
            # 设置音频参数
            audio_config = texttospeech.AudioConfig(
                audio_encoding=texttospeech.AudioEncoding.LINEAR16,
                speaking_rate=speed
            )
            
            # 执行语音合成
            response = self.client.synthesize_speech(
                input=synthesis_input,
                voice=voice,
                audio_config=audio_config
            )
            
            # 保存音频文件
            with open(output_file, 'wb') as out:
                out.write(response.audio_content)
            
            tts_logger.info('Audio file saved successfully to: %s', output_file)
            return True
            
        except Exception as e:
            tts_logger.error('Google TTS generation failed: %s', str(e))
            return False