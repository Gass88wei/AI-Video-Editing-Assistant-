import json
import os
from enum import Enum

class Language(Enum):
    CHINESE = 'zh_CN'
    ENGLISH = 'en_US'

class I18nManager:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(I18nManager, cls).__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self):
        self.current_language = Language.CHINESE
        self.translations = {}
        self._load_translations()
    
    def _load_translations(self):
        # 加载所有语言文件
        for lang in Language:
            lang_file = os.path.join('static', 'i18n', f'{lang.value}.json')
            try:
                if os.path.exists(lang_file):
                    with open(lang_file, 'r', encoding='utf-8') as f:
                        self.translations[lang] = json.load(f)
                else:
                    # 如果文件不存在，使用默认翻译
                    self.translations[lang] = self._get_default_translations(lang)
                    # 确保目录存在
                    os.makedirs(os.path.dirname(lang_file), exist_ok=True)
                    # 保存默认翻译到文件
                    with open(lang_file, 'w', encoding='utf-8') as f:
                        json.dump(self.translations[lang], f, ensure_ascii=False, indent=4)
            except Exception as e:
                print(f"Error loading translation file {lang_file}: {str(e)}")
                self.translations[lang] = self._get_default_translations(lang)
    
    def _get_default_translations(self, language):
        """获取默认翻译"""
        if language == Language.CHINESE:
            return {
                # 通用
                "app_title": "智能视频剪辑助手",
                "browse": "浏览",
                "start": "开始生成",
                "settings": "设置",
                "save": "保存",
                "test": "测试",
                "success": "成功",
                "error": "错误",
                "warning": "警告",
                "info": "信息",
                
                # 导航
                "nav_text_driven": "文案驱动剪辑",
                "nav_auto_generate": "智能生成剪辑",
                "nav_settings": "设置",
                
                # 文案驱动界面
                "script_input": "文案输入",
                "script_placeholder": "请输入或粘贴文案内容",
                "select_image_folder": "选择图片文件夹",
                "select_video_folder": "选择视频文件夹",
                "status_waiting": "等待开始...",
                "generation_complete": "生成完成",
                "generation_failed": "生成失败",
                
                # 智能生成界面
                "material_selection": "素材选择",
                "select_material_folder": "选择素材文件夹",
                "auto_generate_script": "智能生成文案",
                "generate_script_btn": "生成文案",
                "start_generate_video": "开始生成视频",
                "script_generated": "文案生成完成",
                
                # 设置界面
                "model_config": "模型配置",
                "gguf_model_config": "GGUF模型配置",
                "select_gguf_model": "选择GGUF模型文件路径",
                "model_params": "模型参数配置",
                "context_length": "上下文长度:",
                "temperature": "温度:",
                "ollama_config": "Ollama配置",
                "ollama_url_placeholder": "Ollama服务器地址 (例如: http://localhost:11434)",
                "model_type": "模型类型",
                "model_type_local": "GGUF本地模型",
                "model_type_ollama": "Ollama服务",
                "test_model": "测试模型连接",
                "save_settings": "保存设置",
                
                # 语音设置
                "voice_config": "语音配置",
                "voice_mode": "语音模式",
                "voice_mode_local": "本地语音",
                "voice_mode_api": "外部API",
                "api_config": "API配置",
                "api_key": "API密钥",
                "api_url": "API服务器地址",
                "voice_params": "语音参数",
                "voice_type": "音色:",
                "voice_speed": "语速:",
                "voice_emotion": "情感程度:",
                
                # 提示信息
                "fill_all_fields": "请填写完整的文案和素材路径",
                "select_material_first": "请先选择素材文件夹",
                "ensure_material_and_script": "请确保已选择素材文件夹并生成文案",
                "select_gguf_file": "请选择GGUF模型文件",
                "gguf_not_exist": "GGUF模型文件不存在",
                "gguf_verified": "GGUF模型文件验证成功",
                "enter_ollama_url": "请输入Ollama服务器地址",
                "ollama_test_not_implemented": "Ollama服务器连接测试待实现",
                "settings_saved": "设置已保存",
                "settings_save_failed": "保存设置失败: {0}",
                "settings_load_failed": "加载设置失败: {0}",
                
                # 处理状态
                "processing_images": "正在处理图片素材...",
                "processing_videos": "正在处理视频素材...",
                "generating_audio": "正在生成语音...",
                "composing_video": "正在合成最终视频...",
                "video_generation_complete": "视频生成完成！\n保存路径：{0}",
                
                # 错误信息
                "image_dir_not_exist": "图片文件夹不存在",
                "video_dir_not_exist": "视频文件夹不存在",
                "audio_generation_failed": "语音生成失败",
                "no_materials_found": "没有找到可用的素材",
                "low_memory_warning": "内存不足，正在清理..."
            }
        elif language == Language.ENGLISH:
            return {
                # Common
                "app_title": "Smart Video Editing Assistant",
                "browse": "Browse",
                "start": "Start",
                "settings": "Settings",
                "save": "Save",
                "test": "Test",
                "success": "Success",
                "error": "Error",
                "warning": "Warning",
                "info": "Information",
                
                # Navigation
                "nav_text_driven": "Text-Driven Editing",
                "nav_auto_generate": "Auto-Generate Editing",
                "nav_settings": "Settings",
                
                # Text-Driven Interface
                "script_input": "Script Input",
                "script_placeholder": "Enter or paste your script content",
                "select_image_folder": "Select Image Folder",
                "select_video_folder": "Select Video Folder",
                "status_waiting": "Waiting to start...",
                "generation_complete": "Generation Complete",
                "generation_failed": "Generation Failed",
                
                # Auto-Generate Interface
                "material_selection": "Material Selection",
                "select_material_folder": "Select Material Folder",
                "auto_generate_script": "Auto-Generate Script",
                "generate_script_btn": "Generate Script",
                "start_generate_video": "Start Generating Video",
                "script_generated": "Script generation completed",
                
                # Settings Interface
                "model_config": "Model Configuration",
                "gguf_model_config": "GGUF Model Configuration",
                "select_gguf_model": "Select GGUF Model File Path",
                "model_params": "Model Parameters",
                "context_length": "Context Length:",
                "temperature": "Temperature:",
                "ollama_config": "Ollama Configuration",
                "ollama_url_placeholder": "Ollama Server URL (e.g., http://localhost:11434)",
                "model_type": "Model Type",
                "model_type_local": "GGUF Local Model",
                "model_type_ollama": "Ollama Service",
                "test_model": "Test Model Connection",
                "save_settings": "Save Settings",
                
                # Voice Settings
                "voice_config": "Voice Configuration",
                "voice_mode": "Voice Mode",
                "voice_mode_local": "Local Voice",
                "voice_mode_api": "External API",
                "api_config": "API Configuration",
                "api_key": "API Key",
                "api_url": "API Server URL",
                "voice_params": "Voice Parameters",
                "voice_type": "Voice Type:",
                "voice_speed": "Speed:",
                "voice_emotion": "Emotion Level:",
                
                # Prompts
                "fill_all_fields": "Please fill in all script and material paths",
                "select_material_first": "Please select a material folder first",
                "ensure_material_and_script": "Please ensure you have selected a material folder and generated a script",
                "select_gguf_file": "Please select a GGUF model file",
                "gguf_not_exist": "GGUF model file does not exist",
                "gguf_verified": "GGUF model file verified successfully",
                "enter_ollama_url": "Please enter Ollama server URL",
                "ollama_test_not_implemented": "Ollama server connection test not implemented yet",
                "settings_saved": "Settings saved",
                "settings_save_failed": "Failed to save settings: {0}",
                "settings_load_failed": "Failed to load settings: {0}",
                
                # Processing Status
                "processing_images": "Processing image materials...",
                "processing_videos": "Processing video materials...",
                "generating_audio": "Generating audio...",
                "composing_video": "Composing final video...",
                "video_generation_complete": "Video generation complete!\nSaved to: {0}",
                
                # Error Messages
                "image_dir_not_exist": "Image directory does not exist",
                "video_dir_not_exist": "Video directory does not exist",
                "audio_generation_failed": "Audio generation failed",
                "no_materials_found": "No usable materials found",
                "low_memory_warning": "Low memory, cleaning up..."
            }
        return {}
    
    def set_language(self, language):
        """设置当前语言"""
        if language in Language and language in self.translations:
            self.current_language = language
            return True
        return False
    
    def get_text(self, key, default=None, **kwargs):
        """获取翻译文本，支持格式化参数"""
        if self.current_language not in self.translations:
            return default or key
        
        text = self.translations[self.current_language].get(key, default or key)
        
        # 如果有格式化参数，应用它们
        if kwargs:
            try:
                return text.format(**kwargs)
            except (KeyError, IndexError):
                try:
                    # 尝试使用位置参数
                    return text.format(*kwargs.values())
                except:
                    return text
        return text

# 创建单例实例
i18n = I18nManager()

# 简便函数
def _(key, default=None, **kwargs):
    """获取翻译的快捷方式"""
    return i18n.get_text(key, default, **kwargs)