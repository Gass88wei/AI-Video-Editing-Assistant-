import os
import shutil
import psutil
import threading
import concurrent.futures
import time
from typing import List, Callable, Any, Dict, Optional
from logger import video_logger

class MemoryManager:
    def __init__(self, temp_dir='temp', threshold_mb=1000, cache_size_mb=500):
        self.temp_dir = temp_dir
        self.threshold_mb = threshold_mb
        self.cache_size_mb = cache_size_mb
        self.temp_files = set()
        self.cache = {}
        self.cache_usage = 0  # 当前缓存使用量（MB）
        self.lock = threading.RLock()  # 用于线程安全操作
        self.max_workers = min(32, (os.cpu_count() or 4) + 4)  # 并行处理的最大工作线程数
        
        # 创建临时目录和缓存目录
        self.cache_dir = os.path.join(temp_dir, 'cache')
        os.makedirs(temp_dir, exist_ok=True)
        os.makedirs(self.cache_dir, exist_ok=True)
        video_logger.info('MemoryManager initialized with temp directory: %s, max workers: %d', 
                         temp_dir, self.max_workers)
    
    def check_memory_usage(self):
        """检查系统内存使用情况"""
        memory = psutil.virtual_memory()
        available_mb = memory.available / (1024 * 1024)
        if available_mb < self.threshold_mb:
            video_logger.warning('Low memory warning: %d MB available', available_mb)
            self.clean_temp_files()
            return False
        return True
    
    def register_temp_file(self, file_path):
        """注册临时文件以便后续清理"""
        self.temp_files.add(file_path)
        video_logger.debug('Registered temp file: %s', file_path)
    
    def clean_temp_files(self):
        """清理所有注册的临时文件"""
        for file_path in self.temp_files.copy():
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
                    self.temp_files.remove(file_path)
                    video_logger.info('Cleaned temp file: %s', file_path)
            except Exception as e:
                video_logger.error('Failed to clean temp file %s: %s', file_path, str(e))
    
    def split_large_file(self, file_path, chunk_size_mb=100):
        """将大文件分割成小块处理，支持智能分块和并行处理"""
        # 检查缓存中是否已有处理结果
        cache_key = f"split_{file_path}_{chunk_size_mb}"
        cached_result = self.get_from_cache(cache_key)
        if cached_result:
            video_logger.info('Using cached chunks for file: %s', file_path)
            return cached_result
            
        chunk_size = chunk_size_mb * 1024 * 1024  # 转换为字节
        if not os.path.exists(file_path):
            video_logger.error('File not found: %s', file_path)
            return []
        
        file_size = os.path.getsize(file_path)
        if file_size <= chunk_size:
            return [file_path]
        
        # 智能分块：根据文件大小和可用内存动态调整分块大小
        available_memory = psutil.virtual_memory().available / (1024 * 1024)  # MB
        optimal_chunk_count = max(2, min(self.max_workers, int(file_size / (chunk_size * 0.8))))
        adaptive_chunk_size = min(chunk_size, int(file_size / optimal_chunk_count))
        
        video_logger.info('Adaptive splitting: file size: %d MB, chunks: %d, chunk size: %d MB', 
                         file_size/(1024*1024), optimal_chunk_count, adaptive_chunk_size/(1024*1024))
        
        chunks = []
        try:
            base_name = os.path.basename(file_path)
            name, ext = os.path.splitext(base_name)
            
            # 计算分块位置
            chunk_positions = []
            total_chunks = int(file_size / adaptive_chunk_size) + (1 if file_size % adaptive_chunk_size > 0 else 0)
            
            for i in range(total_chunks):
                start_pos = i * adaptive_chunk_size
                end_pos = min((i + 1) * adaptive_chunk_size, file_size)
                chunk_positions.append((i, start_pos, end_pos))
            
            # 并行处理分块
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(self.max_workers, total_chunks)) as executor:
                future_to_chunk = {}
                
                for chunk_num, start_pos, end_pos in chunk_positions:
                    chunk_path = os.path.join(
                        self.temp_dir,
                        f'{name}_chunk_{chunk_num}{ext}'
                    )
                    
                    future = executor.submit(
                        self._write_chunk_file, 
                        file_path, 
                        chunk_path, 
                        start_pos, 
                        end_pos - start_pos
                    )
                    future_to_chunk[future] = chunk_path
                
                # 收集结果
                for future in concurrent.futures.as_completed(future_to_chunk):
                    chunk_path = future_to_chunk[future]
                    try:
                        if future.result():
                            chunks.append(chunk_path)
                            self.register_temp_file(chunk_path)
                    except Exception as e:
                        video_logger.error('Error processing chunk %s: %s', chunk_path, str(e))
            
            # 按顺序排序分块
            chunks.sort(key=lambda x: int(x.split('_chunk_')[1].split('.')[0]))
            
            video_logger.info('Split %s into %d chunks using parallel processing', file_path, len(chunks))
            
            # 将结果存入缓存
            self.add_to_cache(cache_key, chunks)
            return chunks
        except Exception as e:
            video_logger.error('Failed to split file %s: %s', file_path, str(e))
            return []
    
    def _write_chunk_file(self, source_file, chunk_path, start_pos, size):
        """从源文件中读取指定位置和大小的数据，写入分块文件"""
        try:
            with open(source_file, 'rb') as src, open(chunk_path, 'wb') as dst:
                src.seek(start_pos)
                dst.write(src.read(size))
            return True
        except Exception as e:
            video_logger.error('Failed to write chunk file %s: %s', chunk_path, str(e))
            return False
    
    def process_in_parallel(self, items: List[Any], process_func: Callable, max_workers: Optional[int] = None) -> List[Any]:
        """并行处理多个项目
        
        Args:
            items: 要处理的项目列表
            process_func: 处理函数，接收一个项目作为参数
            max_workers: 最大工作线程数，默认使用self.max_workers
            
        Returns:
            处理结果列表
        """
        if not items:
            return []
            
        workers = max_workers or self.max_workers
        results = []
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            future_to_item = {executor.submit(process_func, item): item for item in items}
            
            for future in concurrent.futures.as_completed(future_to_item):
                item = future_to_item[future]
                try:
                    result = future.result()
                    if result is not None:
                        results.append(result)
                except Exception as e:
                    video_logger.error('Error processing item %s: %s', str(item), str(e))
        
        return results
    
    def add_to_cache(self, key: str, value: Any) -> bool:
        """添加数据到缓存"""
        with self.lock:
            # 估算缓存大小（简单实现，实际应用中可能需要更精确的计算）
            size_mb = self._estimate_size(value) / (1024 * 1024)
            
            # 如果缓存空间不足，清理部分缓存
            if self.cache_usage + size_mb > self.cache_size_mb:
                self._evict_cache(size_mb)
            
            # 添加到缓存
            self.cache[key] = {
                'value': value,
                'size_mb': size_mb,
                'last_access': time.time()
            }
            self.cache_usage += size_mb
            video_logger.debug('Added to cache: %s (%.2f MB)', key, size_mb)
            return True
    
    def get_from_cache(self, key: str) -> Any:
        """从缓存获取数据"""
        with self.lock:
            if key in self.cache:
                # 更新最后访问时间
                self.cache[key]['last_access'] = time.time()
                return self.cache[key]['value']
            return None
    
    def _estimate_size(self, obj: Any) -> int:
        """估算对象大小（字节）"""
        if isinstance(obj, str):
            return len(obj.encode('utf-8'))
        elif isinstance(obj, bytes):
            return len(obj)
        elif isinstance(obj, (list, tuple)):
            return sum(self._estimate_size(item) for item in obj)
        elif isinstance(obj, dict):
            return sum(self._estimate_size(k) + self._estimate_size(v) for k, v in obj.items())
        else:
            # 对于其他类型，返回一个默认大小
            return 1024  # 1KB
    
    def _evict_cache(self, required_space_mb: float):
        """清理缓存以释放指定空间"""
        # 按最后访问时间排序
        sorted_cache = sorted(
            self.cache.items(),
            key=lambda x: x[1]['last_access']
        )
        
        freed_space = 0
        for key, info in sorted_cache:
            if freed_space >= required_space_mb:
                break
                
            freed_space += info['size_mb']
            self.cache_usage -= info['size_mb']
            del self.cache[key]
            video_logger.debug('Evicted from cache: %s (%.2f MB)', key, info['size_mb'])
    
    def __del__(self):
        """析构时清理所有临时文件"""
        self.clean_temp_files()
        if os.path.exists(self.temp_dir):
            try:
                shutil.rmtree(self.temp_dir)
                video_logger.info('Cleaned temp directory: %s', self.temp_dir)
            except Exception as e:
                video_logger.error('Failed to clean temp directory: %s', str(e))