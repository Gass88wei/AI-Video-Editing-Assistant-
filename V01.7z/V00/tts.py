import asyncio
import os
from logger import tts_logger
from tts_factory import TTSFactory

voice_list = ["am_puck", "af_bella", "am_adam"]

async def text_to_audio(text, voice_name, speed, output_file, provider_type='gradio'):
    """
    将文本转换为语音
    
    Args:
        text: 要转换的文本
        voice_name: 语音名称
        speed: 语速
        output_file: 输出文件路径
        provider_type: TTS提供者类型，支持'gradio', 'azure', 'google', 'local'
    
    Returns:
        bool: 是否成功
    """
    try:
        tts_logger.info('Starting TTS generation with provider: %s, voice: %s', provider_type, voice_name)
        
        # 创建TTS提供者实例
        provider_kwargs = {}
        
        # 根据不同提供者设置特定参数
        if provider_type == 'azure':
            provider_kwargs['subscription_key'] = os.getenv('AZURE_TTS_KEY')
            provider_kwargs['region'] = os.getenv('AZURE_TTS_REGION', 'eastus')
        elif provider_type == 'google':
            provider_kwargs['credentials_path'] = os.getenv('GOOGLE_APPLICATION_CREDENTIALS')
        elif provider_type == 'gradio':
            provider_kwargs['server_url'] = os.getenv("TTS_SERVER_URL", "http://localhost:7860/")
        
        # 使用工厂创建提供者
        try:
            provider = TTSFactory.create_provider(provider_type, **provider_kwargs)
        except ValueError as e:
            tts_logger.error('Failed to create TTS provider: %s, falling back to gradio', str(e))
            provider = TTSFactory.create_provider('gradio', server_url=os.getenv("TTS_SERVER_URL", "http://localhost:7860/"))
        
        # 生成语音
        success = await provider.generate_speech(
            text=text,
            voice_name=voice_name,
            speed=speed,
            output_file=output_file
        )
        
        if success:
            tts_logger.info('Audio file generated successfully')
        else:
            tts_logger.error('Failed to generate audio file')
        
        return success
    except Exception as e:
        tts_logger.error('TTS generation failed: %s', str(e))
        return False