import os
import json
from abc import ABC, abstractmethod
import requests
from logger import video_logger

class LLMProvider(ABC):
    """LLM服务提供商的抽象基类"""
    
    @abstractmethod
    def generate_text(self, prompt, max_tokens=1000, temperature=0.7):
        """生成文本的抽象方法"""
        pass
    
    @abstractmethod
    def test_connection(self):
        """测试连接的抽象方法"""
        pass

class OpenAIProvider(LLMProvider):
    """OpenAI API服务提供商"""
    
    def __init__(self, api_key, api_url=None, model="gpt-3.5-turbo"):
        self.api_key = api_key
        self.api_url = api_url or "https://api.openai.com/v1/chat/completions"
        self.model = model
        video_logger.info(f"Initialized OpenAI provider with model: {model}")
    
    def generate_text(self, prompt, max_tokens=1000, temperature=0.7):
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }
            
            data = {
                "model": self.model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": temperature
            }
            
            video_logger.debug(f"Sending request to OpenAI API with prompt length: {len(prompt)}")
            response = requests.post(self.api_url, headers=headers, json=data)
            response.raise_for_status()
            
            result = response.json()
            generated_text = result["choices"][0]["message"]["content"]
            video_logger.debug(f"Received response from OpenAI API with length: {len(generated_text)}")
            
            return generated_text
        except Exception as e:
            video_logger.error(f"Error generating text with OpenAI: {str(e)}")
            raise
    
    def test_connection(self):
        try:
            # 使用一个简单的提示测试连接
            test_prompt = "Hello, this is a connection test."
            self.generate_text(test_prompt, max_tokens=10)
            return True, "Connection successful"
        except Exception as e:
            return False, f"Connection failed: {str(e)}"

class AzureOpenAIProvider(LLMProvider):
    """Azure OpenAI API服务提供商"""
    
    def __init__(self, api_key, api_url, deployment_name):
        self.api_key = api_key
        self.api_url = api_url
        self.deployment_name = deployment_name
        video_logger.info(f"Initialized Azure OpenAI provider with deployment: {deployment_name}")
    
    def generate_text(self, prompt, max_tokens=1000, temperature=0.7):
        try:
            headers = {
                "Content-Type": "application/json",
                "api-key": self.api_key
            }
            
            data = {
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": temperature
            }
            
            endpoint = f"{self.api_url}/openai/deployments/{self.deployment_name}/chat/completions?api-version=2023-05-15"
            
            video_logger.debug(f"Sending request to Azure OpenAI API with prompt length: {len(prompt)}")
            response = requests.post(endpoint, headers=headers, json=data)
            response.raise_for_status()
            
            result = response.json()
            generated_text = result["choices"][0]["message"]["content"]
            video_logger.debug(f"Received response from Azure OpenAI API with length: {len(generated_text)}")
            
            return generated_text
        except Exception as e:
            video_logger.error(f"Error generating text with Azure OpenAI: {str(e)}")
            raise
    
    def test_connection(self):
        try:
            # 使用一个简单的提示测试连接
            test_prompt = "Hello, this is a connection test."
            self.generate_text(test_prompt, max_tokens=10)
            return True, "Connection successful"
        except Exception as e:
            return False, f"Connection failed: {str(e)}"

class AnthropicProvider(LLMProvider):
    """Anthropic API服务提供商"""
    
    def __init__(self, api_key, api_url=None, model="claude-2"):
        self.api_key = api_key
        self.api_url = api_url or "https://api.anthropic.com/v1/messages"
        self.model = model
        video_logger.info(f"Initialized Anthropic provider with model: {model}")
    
    def generate_text(self, prompt, max_tokens=1000, temperature=0.7):
        try:
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01"
            }
            
            data = {
                "model": self.model,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": temperature
            }
            
            video_logger.debug(f"Sending request to Anthropic API with prompt length: {len(prompt)}")
            response = requests.post(self.api_url, headers=headers, json=data)
            response.raise_for_status()
            
            result = response.json()
            generated_text = result["content"][0]["text"]
            video_logger.debug(f"Received response from Anthropic API with length: {len(generated_text)}")
            
            return generated_text
        except Exception as e:
            video_logger.error(f"Error generating text with Anthropic: {str(e)}")
            raise
    
    def test_connection(self):
        try:
            # 使用一个简单的提示测试连接
            test_prompt = "Hello, this is a connection test."
            self.generate_text(test_prompt, max_tokens=10)
            return True, "Connection successful"
        except Exception as e:
            return False, f"Connection failed: {str(e)}"

class CustomProvider(LLMProvider):
    """自定义API服务提供商"""
    
    def __init__(self, api_key, api_url, headers=None, request_template=None, response_path=None):
        self.api_key = api_key
        self.api_url = api_url
        self.headers = headers or {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}
        self.request_template = request_template or '{"prompt": "%s", "max_tokens": %d, "temperature": %f}'
        self.response_path = response_path or "text"
        video_logger.info(f"Initialized Custom provider with URL: {api_url}")
    
    def generate_text(self, prompt, max_tokens=1000, temperature=0.7):
        try:
            # 准备请求数据
            if isinstance(self.request_template, str):
                # 如果是字符串模板，使用格式化
                request_data = self.request_template % (prompt, max_tokens, temperature)
                # 转换为JSON对象
                data = json.loads(request_data)
            else:
                # 如果是字典模板，使用字典更新
                data = self.request_template.copy()
                data.update({
                    "prompt": prompt,
                    "max_tokens": max_tokens,
                    "temperature": temperature
                })
            
            video_logger.debug(f"Sending request to Custom API with prompt length: {len(prompt)}")
            response = requests.post(self.api_url, headers=self.headers, json=data)
            response.raise_for_status()
            
            result = response.json()
            
            # 从响应中提取文本
            if self.response_path:
                path_parts = self.response_path.split('.')
                value = result
                for part in path_parts:
                    if part.isdigit():
                        value = value[int(part)]
                    elif '[' in part and ']' in part:
                        # 处理形如 "choices[0].text" 的路径
                        key, index = part.split('[', 1)
                        index = int(index.split(']', 1)[0])
                        value = value[key][index]
                    else:
                        value = value[part]
                generated_text = value
            else:
                generated_text = str(result)
            
            video_logger.debug(f"Received response from Custom API with length: {len(generated_text)}")
            return generated_text
        except Exception as e:
            video_logger.error(f"Error generating text with Custom provider: {str(e)}")
            raise
    
    def test_connection(self):
        try:
            # 使用一个简单的提示测试连接
            test_prompt = "Hello, this is a connection test."
            self.generate_text(test_prompt, max_tokens=10)
            return True, "Connection successful"
        except Exception as e:
            return False, f"Connection failed: {str(e)}"

class LLMFactory:
    """LLM服务提供商工厂类"""
    
    @staticmethod
    def create_provider(provider_type, **kwargs):
        """创建LLM服务提供商实例"""
        if provider_type.lower() == "openai":
            return OpenAIProvider(
                api_key=kwargs.get("api_key"),
                api_url=kwargs.get("api_url"),
                model=kwargs.get("model", "gpt-3.5-turbo")
            )
        elif provider_type.lower() == "azure":
            return AzureOpenAIProvider(
                api_key=kwargs.get("api_key"),
                api_url=kwargs.get("api_url"),
                deployment_name=kwargs.get("deployment_name")
            )
        elif provider_type.lower() == "anthropic":
            return AnthropicProvider(
                api_key=kwargs.get("api_key"),
                api_url=kwargs.get("api_url"),
                model=kwargs.get("model", "claude-2")
            )
        elif provider_type.lower() == "custom":
            return CustomProvider(
                api_key=kwargs.get("api_key"),
                api_url=kwargs.get("api_url"),
                headers=kwargs.get("headers"),
                request_template=kwargs.get("request_template"),
                response_path=kwargs.get("response_path")
            )
        else:
            raise ValueError(f"Unknown provider type: {provider_type}")